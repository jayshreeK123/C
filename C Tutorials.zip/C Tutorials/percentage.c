#include<stdio.h>
#include<math.h>

int calcPercentage(int science , int math , int sanskrit);

int main(){
    int science, math,sanskrit;
    printf("Enter Science marks : ");
    scanf("%d",&science);
    printf("Enter math marks : ");
    scanf("%d",&math);
    printf("Enter sanskrit marks : ");
    scanf("%d",&sanskrit);

    printf("Total Percentage is : %d", calcPercentage(science,math,sanskrit));
    return 0;
}

int calcPercentage(int science , int math , int sanskrit){
    return((science + math + sanskrit) / 3);
}