#include<stdio.h>

int main(){
    int marks;
    printf("Enter marks :");
    scanf("%d", &marks);

    if(marks < 30){
        printf("C \n");
    }
    else if(marks >= 30 && marks <70){
        printf("B \n");
    }
    else if(marks >= 70 && marks <90){
        printf("A \n");
    }
    else{
        printf("A+ \n");
    }
    
    return 0;
    
}

// if(x=1){
//         printf("x is equal to 1");
//     }else{
//         printf("x is not equal to 1");
//     }

//     o/p : x is equal to 1