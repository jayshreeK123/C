#include<stdio.h>
#include<math.h>

int main(){
    int isMonday = 0;
    int isRaining = 1;
    printf("%d \n", isMonday || isRaining);
    return 0;
}