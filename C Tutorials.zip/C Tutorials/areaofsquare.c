#include<stdio.h>
#include<math.h>

float squareArea(float side);
float circleArea(float rad );
float rectangleArea(float a , float b);

int main(){
    float a, b , side ,rad ;

    printf("Enter sides of rectangle numbers :");
    scanf("%f %f",&a , &b);

    printf("Enter sides square :");
    scanf("%f" , &side);

    printf("Enter radius of circle : ");
    scanf("%f" , &rad)

    return 0;
}
float squareArea(float side){
    return side * side;
}
float circleArea(float side){
    return 3.14 * rad * rad;
}
float rectangleArea(float a , float b){
    return a*b;
}