#include<stdio.h>
#include<math.h>

int main(){
    //even -> 1
    //odd -> 0
    int a;
    printf("Enter a number:");
    scanf("%d",&a);
    printf("%d", a%2 ==0);
    return 0;
} 