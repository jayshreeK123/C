#include<stdio.h>

int main(){
    int a,b,sum;
    printf("ENTER TWO NUMBER  :");
    scanf("%d %d", &a , &b);
    sum = a+b;
    printf("Sum is  : %d", sum);
    return 0 ;

}