#include<stdio.h>
#include<math.h>

int main(){
    //number greater than 9 and less than 100

    int x;
    printf("Enter number :");
    scanf("%d", &x);
    printf("%d \n", x>9 && x<100);
    return 0;
}