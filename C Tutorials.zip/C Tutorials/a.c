#include<stdio.h>

int main(){
    int a= 20 , b = 7;
    int sum = a+b;
    int multiply = a*b;
    return 0;

}