#include<stdio.h>

int main(){
    int i=1, n , sum=0;
    float avg ;
    printf("Enter 5 positive number : \n\t");
    while(i<=5){
        printf(" Enter Number %d :", i);
        scanf("%d",&n);
        if(n<0){
            printf("Enter only Positive number\n");
            continue;
        }
        sum += n;
        i++;
    }
    avg = sum/10.0;
    printf("sum=%d  Avg=%f\n", sum , avg);
    return 0;
}