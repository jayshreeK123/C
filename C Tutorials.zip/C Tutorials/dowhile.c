#include<stdio.h>

int main(){
    int n , sum=0 ,count=0 ;
    printf("Enter a Number :");
    scanf("%d",&n);
    do{
        n/=10;
        count++;
    }while(n>0);
    printf("Number of Digit = %d" ,count);
    return 0;
}