#include<stdio.h>
#include<math.h>

int main(){
    //check if given charachter is digit or not
    char ch;
    printf("Enter charachter :");
    scanf("%c",&ch);

    if (ch >= '0' && ch <= '9') {
        printf("The character '%c' is a digit.\n", ch);
    } else {
        printf("The character '%c' is not a digit.\n", ch);
    }
    return 0 ;
}