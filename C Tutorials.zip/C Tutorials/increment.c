#include<stdio.h>

int main(){
    // increment & decrement operator

    //i++ pre increment
    //++i post increment

    // i-- pre decrement
    // --i post decrement

    int i = 1;
    printf("%d\n", i++ );
    printf("%d\n", i);

    printf("%d \n", ++i);
    printf("%d \n", i);

    return 0 ;

}