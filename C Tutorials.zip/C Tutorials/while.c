#include<stdio.h>

int main(){
    int n;
    printf("Enter the number :");
    scanf("%d",&n);

    int k = n; 
    while(k>=2){
        printf("%d\n",k);
        k=k-2;
    }
    printf("\n");
    return 0;
}