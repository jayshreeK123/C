#include<stdio.h>

int main(){
    int day ;
    printf("Enter day (1-7):");
    scanf("%d", &day);

    switch (day) {
        case 1 : printf("monday");
                break;
        case 2 : printf("tuesday");
                break;
        case 3 : printf("Wednesday");
                break;
        case 4 : printf("thrusday");
                break;
        case 5 : printf("fridayy");
                break;
        case 6 : printf("saturday");
                break;
        case 7 : printf("sunday");
                break;

        default : printf("Not a valid ! \n");
        
    }
}