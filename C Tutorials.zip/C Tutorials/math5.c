#include<stdio.h>
#include<math.h>

int main()
{
    // print the smallest number
    int a , b;

    printf("Enter two number :");
    scanf("%d %d", &a , &b);

    if(a<b)
    {
        printf("smallest number is %d",a);
    }
    else if(a=b)
    {
        printf("smallest number is %d",0);
    }
    else
    {
        printf("smallest number is %d", b);
    }
    return 0;
}