#include<stdio.h>

void star();
int main(){
    star();
    return 0;
}
void star(){
    int i,j;
    for(i=1 ; i<=5;i++){
        for(j=1;j<=i;j++)
            printf("*");
        printf("\n");

    }
        
}