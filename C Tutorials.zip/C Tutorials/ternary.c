#include<stdio.h>
#include<math.h>

int main(){
    int age;
    printf("Enter Age :");
    scanf("%d", &age);

    age>= 18 ? printf("Adult\n") : printf("not adult \n");

    return 0;
}