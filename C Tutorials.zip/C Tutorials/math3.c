#include<stdio.h>
#include<math.h>

int main(){

//Average of three numbers

    float num1 , num2, num3 , avg;
    printf("Enter the Numbers :");
    scanf("%f%f%f", &num1,&num2,&num3);
    avg = num1+num2+num3/3;
    printf("%f",avg);
    return 0;
}