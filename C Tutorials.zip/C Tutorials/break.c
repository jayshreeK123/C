#include<stdio.h>

int main(){
    // taking number as input from user until user enters odd number
    int n;
    do{
        printf("Enter Number : ");
        scanf("%d" , &n);
        printf("%d\n",n);
        
        if(n % 2 !=0){
            break;
        }
    }
    while(1);
    printf("Thank You !!");

    return 0;
}