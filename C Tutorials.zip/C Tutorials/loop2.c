#include<stdio.h>
// Maths Table

int main(){
    int n ;
    printf("Enetr the number :");
    scanf("%d", &n);

    for(int i=1; i<=10; i++){
        printf("%d \n", n*i);
    }
    return 0;
}
